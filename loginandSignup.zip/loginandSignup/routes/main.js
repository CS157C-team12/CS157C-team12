const express = require('express');
const router = express.Router();
const passport = require('passport');
const address = require('address'); 
const phone = require('phone');
const crypto = require('crypto');
const async = require('async');
const nodemailer = require('nodemailer');
const cart = require('../models/cart');
const Product = require('../models/productmodel');
const mongoose = require('mongoose');

router.get('/products/:id',function(req,res,next){
    product
       .find({ category: req.params.id})
       .populate('category')
       .exec(function(err,products){
           if(err) return next(err);
           res.render('main/category',{
               products: products
           });
       });
});
router.post('/product/:product_id', function(req,res,next){
    cart.findOne({name: req.user._id}, function(err,cart){
        cart.items.push({
            item: req.body.product_id,
            price: parseFloat(req.body.priceValue),
            quantity:parseInt(req.body.quantity),
        });
        cart.total = (cart.total + parseFloat(req.body.priceValue));
        cart.save(function(err){
            return res.redirect('/cart');
        });
    });
});

//get router for cart
router.get('/cart',function(req,res,next){
   Cart
      .findOne({ owner: req.user._id})
      .populate('items.item')
      .exec(function(err,foundCart){
          if (err) return next(err);
          res.render('main/cart',{
              cart: foundCart

          });
      });
});

module.exports = router;