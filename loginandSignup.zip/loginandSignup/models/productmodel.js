/*const mongoose = require('mongoose');
const passportLocalMongoose = require('passport-local-mongoose');

let userScheme = new mongoose.Schema({
    id:{type: String},
    productPic:{type: String},
    title:{type: String},
    price:{type: String},
    detail:{type: String}
});

// userScheme.plugin(passportLocalMongoose, {usernameField : 'email'})
module.exports = mongoose.model('product', userScheme);*/

var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var ProductSchema = new Schema({
    category: { type:Schema.Types.ObjectId, ref: 'Category'},
    name: String,
    price: Number,
    image: String
});

module.exprots = mongoose.model('Product',ProductSchema);