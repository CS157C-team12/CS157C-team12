const mongoose = require('mongoose');
const passportLocalMongoose = require('passport-local-mongoose');

let userScheme = new mongoose.Schema({
    name : {type: String},
    orderDate : {type: Date},
    total : {type: String},
    orderNumber: {type: String},
});

userScheme.plugin(passportLocalMongoose, {usernameField : 'email'});
module.exports = mongoose.model('Order', userScheme);